package com.ArrayList;

public class Infiniteloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		while(1==1) {
			System.out.println("Im stuck in a loop");
		}

	}

}
