package com.ArrayList;

public class ArrayPRoject {

		// TODO Auto-generated constructor stub
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] number = {10, 20, 30, 40, 50};
		
		
		
		System.out.println("First Element" + number[0]);
		System.out.println("First Element" + number[4]);
		
		System.out.println("All elements");
		for (int i = 0; i < number.length; i++) {
		System.out.println(number[i]);
		
		
	}

		

	}

}
