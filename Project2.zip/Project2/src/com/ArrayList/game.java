package com.ArrayList;
import java.util.Scanner;
public class game {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		
		String response = "";
		
		while(!response.equals("Q")) {
			System.out.println("You are in a game");
			System.out.print("Press Q to quit: ");
			response = sc.next().toUpperCase();
		}
		
		System.out.println("You've quit");

	}

}
