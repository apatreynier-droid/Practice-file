package com.ArrayList;
import java.util.Scanner;
public class Project6 {
	
	public static void main(String[] args) throws InterruptedException { 
		Scanner sc = new Scanner(System.in);
		
		System.out.println("How many Seconds to Countdown");
		int start = sc.nextInt();
		
		for (int i = start; i > 0; i--) {
			System.out.println(i);
			Thread.sleep(1000);	
		}
		
		System.out.println("Happy Birthday");
	}

}
