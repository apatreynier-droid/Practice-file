package com.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
public class Projecr4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
	int[] numbers = new int[9];
	
	System.out.println("Enter a number");
	for (int i = 0; i < numbers.length; i++) {
		numbers[i] = sc.nextInt();
		
	}
	
	Arrays.sort(numbers);
	
	System.out.println("Sorted Array :");
	for (int number :  numbers) {
		System.out.println(number + "");
		
	}
	System.out.println();
	
	double sum = 0;
	
	for(int number : numbers) {
		sum += number;
	}
	double mean = sum / numbers.length;
	
	int median = numbers[numbers.length / 2];
	
	int lowest = numbers[0];
	int  highest = numbers[numbers.length - 1];
	
	System.out.println("Mean" + mean);
	System.out.println("median" + median);
	System.out.println("lowest" + lowest);
	System.out.println("highest" + highest);
	

	}

}
