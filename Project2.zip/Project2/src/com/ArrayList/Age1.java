package com.ArrayList;
import java.util.Scanner;
public class Age1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		int age = 0;
				
		
		do {
			System.out.println("Age must not be negative");
			System.out.println("Enter your age");
			age = sc.nextInt();
		}while(age < 0);
					
		
		System.out.println("Your are  " + age + " Years Old");

	}
}

