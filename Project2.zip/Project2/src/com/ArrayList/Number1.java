package com.ArrayList;
import java.util.Scanner;
public class Number1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int number = 0;
		
		while(number < 1 || number > 10) {
			System.out.println("Pick a number between 1-10");
			number = sc.nextInt();
		}
		
		System.out.println("You picked " + number);
	}

}
