package com.testactivity;
import java.util.Scanner;
import java.util.ArrayList;

public class Practice2 {
public  static  void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	ArrayList<String> names = new ArrayList<>();
	
	System.out.println("Type a number");
	int number = sc.nextInt();
	
	if (number > 18) {
		System.out.println("You are qulified");
	} else if (number < 18) {
		System.out.println("You are not qualified");
	}
	
	
}
}
